import { Emitter } from './utils/emitter';

export const appEvents = new Emitter();

export default appEvents;
